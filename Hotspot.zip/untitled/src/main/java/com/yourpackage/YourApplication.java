package com.yourpackage;

import com.yourpackage.security.jwt.AuthEntryPointJwt;
import com.yourpackage.security.jwt.AuthTokenFilter;
import com.yourpackage.service.UserDetailsServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import javax.servlet.Filter;

@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
public class YourApplication<AuthTokenFilter extends Filter> {

    public static void main(String[] args) {
        SpringApplication.run(YourApplication.class, args);
    }

    @Bean
    public FilterRegistrationBean<AuthTokenFilter> filterRegistrationBean() {
        FilterRegistrationBean<AuthTokenFilter> registrationBean = new FilterRegistrationBean<>();
        AuthTokenFilter authTokenFilter = new AuthTokenFilter();

        registrationBean.setFilter(authTokenFilter);
        registrationBean.addUrlPatterns("/api/*");

        return registrationBean;
    }

    @Bean
    public AuthEntryPointJwt unauthorizedHandler() {
        return new AuthEntryPointJwt();
    }

    @Bean
    public UserDetailsServiceImpl userDetailsServiceImpl() {
        return new UserDetailsServiceImpl();
    }
}