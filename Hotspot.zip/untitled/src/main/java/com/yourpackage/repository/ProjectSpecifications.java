package com.yourpackage.repository;

public class ProjectSpecifications {
}
