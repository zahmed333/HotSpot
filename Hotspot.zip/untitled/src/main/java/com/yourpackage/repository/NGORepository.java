package com.yourpackage.repository;

@Repository
public interface NGORepository extends JpaRepository<NGO, Long> {
}