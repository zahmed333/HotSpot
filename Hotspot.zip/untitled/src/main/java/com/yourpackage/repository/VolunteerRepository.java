package com.yourpackage.repository;

@Repository
public interface VolunteerRepository extends JpaRepository<Volunteer, Long> {
}