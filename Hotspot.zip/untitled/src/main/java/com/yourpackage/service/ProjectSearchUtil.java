package com.yourpackage.service;

import com.yourpackage.model.Project;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.List;

public class ProjectSearchUtil {

    private static final String SEARCH_API_URL = "http://localhost:8080/projects/search";

    public static List<Project> searchProjects(String type, String industry, String skills, String location) {
        WebClient webClient = WebClient.create(SEARCH_API_URL);

        Flux<Project> projectFlux = webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .queryParam("type", type)
                        .queryParam("industry", industry)
                        .queryParam("skills", skills)
                        .queryParam("location", location)
                        .build())
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToFlux(Project.class);

        return projectFlux.collectList().block();
    }
}